import { 
  rooms, videos, roomAssignments, schedules, customEntries,
  type Room, type Video, type RoomAssignment, type Schedule, type CustomEntry,
  type InsertRoom, type InsertVideo, type InsertRoomAssignment, type InsertSchedule, type InsertCustomEntry
} from "@shared/schema";

export interface IStorage {
  // Rooms
  getRooms(): Promise<Room[]>;
  getRoom(id: number): Promise<Room | undefined>;
  createRoom(room: InsertRoom): Promise<Room>;
  updateRoom(id: number, room: Partial<Room>): Promise<Room | undefined>;

  // Videos
  getVideos(): Promise<Video[]>;
  getVideo(id: number): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: number, video: Partial<Video>): Promise<Video | undefined>;
  updateVideoLastUsed(id: number): Promise<void>;
  deleteVideo(id: number): Promise<boolean>;

  // Room Assignments
  getRoomAssignments(): Promise<RoomAssignment[]>;
  getRoomAssignmentsByRoom(roomId: number): Promise<RoomAssignment[]>;
  createRoomAssignment(assignment: InsertRoomAssignment): Promise<RoomAssignment>;
  updateRoomAssignment(id: number, assignment: Partial<RoomAssignment>): Promise<RoomAssignment | undefined>;
  deleteRoomAssignment(id: number): Promise<boolean>;
  clearRoomAssignments(roomId: number): Promise<void>;

  // Schedules
  getSchedules(): Promise<Schedule[]>;
  getSchedulesByDate(scheduleDate: string): Promise<Schedule[]>;
  getSchedulesByRoom(roomId: number): Promise<Schedule[]>;
  getSchedulesByRoomAndDate(roomId: number, scheduleDate: string): Promise<Schedule[]>;
  createSchedule(schedule: InsertSchedule): Promise<Schedule>;
  updateSchedule(id: number, schedule: Partial<Schedule>): Promise<Schedule | undefined>;
  deleteSchedule(id: number): Promise<boolean>;

  // Custom Entries
  getCustomEntries(): Promise<CustomEntry[]>;
  getCustomEntriesByCategory(category: string): Promise<CustomEntry[]>;
  createCustomEntry(entry: InsertCustomEntry): Promise<CustomEntry>;
  deleteCustomEntry(category: string, value: string): Promise<boolean>;
}

import { db } from "./db";
import { eq } from "drizzle-orm";

export class MemStorage implements IStorage {
  private rooms: Map<number, Room>;
  private videos: Map<number, Video>;
  private roomAssignments: Map<number, RoomAssignment>;
  private schedules: Map<number, Schedule>;
  private customEntries: Map<number, CustomEntry>;
  private currentId: { rooms: number; videos: number; assignments: number; schedules: number; customEntries: number };

  constructor() {
    this.rooms = new Map();
    this.videos = new Map();
    this.roomAssignments = new Map();
    this.schedules = new Map();
    this.customEntries = new Map();
    this.currentId = { rooms: 1, videos: 1, assignments: 1, schedules: 1, customEntries: 1 };
    this.initializeData();
  }

  private initializeData() {
    // Initialize 10 rooms
    const roomNames = [
      "Round 1 (Warm Up)", "Round 2 (Weights Section)", "Round 3 (Weights Section)", "Round 4 (Heavy Weight Bag)", "Round 5 (Maize Bag)",
      "Round 6 (Multi function wall)", "Round 7 (Muay Thai Bag)", "Round 8 (Core)", "Round 9 (Horizontal Bag)", "Round 10 (Aqua Bag)"
    ];

    roomNames.forEach((name, index) => {
      const room: Room = {
        id: index + 1,
        number: index + 1,
        name,
        isActive: index < 8 ? true : false, // First 8 rooms active
      };
      this.rooms.set(room.id, room);
    });

    // Initialize sample videos
    const sampleVideos = [
      { title: "Push-Up Variations", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", duration: "Loop", bodyPart: "Chest", equipment: "Bodyweight" },
      { title: "Perfect Squats", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4", duration: "Loop", bodyPart: "Legs", equipment: "Bodyweight" },
      { title: "Burpee Technique", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4", duration: "Loop", bodyPart: "Full Body", equipment: "Bodyweight" },
      { title: "Bench Press Form", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4", duration: "Loop", bodyPart: "Chest", equipment: "Barbell" },
      { title: "High Knees", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4", duration: "Loop", bodyPart: "Legs", equipment: "Bodyweight" },
      { title: "Dumbbell Curls", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4", duration: "Loop", bodyPart: "Arms", equipment: "Dumbbell" },
      { title: "Heavy Bag Training", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4", duration: "Loop", bodyPart: "Full Body", equipment: "Boxing Bag" },
      { title: "Medicine Ball Slams", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4", duration: "Loop", bodyPart: "Core", equipment: "Medicine ball" },
      { title: "Speedbag Training", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4", duration: "Loop", bodyPart: "Arms", equipment: "Speedbag" },
      { title: "Kettlebell Swings", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4", duration: "Loop", bodyPart: "Full Body", equipment: "Kettle bells" },
      { title: "Resistance Band Rows", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4", duration: "Loop", bodyPart: "Back", equipment: "Resistance bands" },
      { title: "Stability Ball Crunches", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4", duration: "Loop", bodyPart: "Core", equipment: "Stability ball" },
    ];

    sampleVideos.forEach((video, index) => {
      const videoData: Video = {
        id: index + 1,
        title: video.title,
        url: video.url,
        duration: video.duration,
        bodyPart: video.bodyPart,
        secondaryMuscle: null,
        equipment: video.equipment,
        lastUsed: new Date(Date.now() - Math.random() * 24 * 60 * 60 * 1000), // Random last used within 24 hours
        thumbnailUrl: null,
      };
      this.videos.set(videoData.id, videoData);
    });

    // Initialize some room assignments
    const assignments = [
      { roomId: 1, videoId: 1, sets: 3, reps: 15, restTime: 60, position: 1, isActive: true },
      { roomId: 1, videoId: 2, sets: 4, reps: 12, restTime: 60, position: 2, isActive: true },
      { roomId: 2, videoId: 4, sets: 4, reps: 8, restTime: 90, position: 1, isActive: true },
      { roomId: 3, videoId: 3, sets: 3, reps: 10, restTime: 45, position: 1, isActive: true },
      { roomId: 3, videoId: 7, sets: 4, reps: 20, restTime: 30, position: 2, isActive: true },
      { roomId: 5, videoId: 5, sets: 5, reps: 30, restTime: 30, position: 1, isActive: true },
      { roomId: 5, videoId: 6, sets: 4, reps: 15, restTime: 45, position: 2, isActive: true },
    ];

    assignments.forEach((assignment, index) => {
      const assignmentData: RoomAssignment = {
        id: index + 1,
        roomId: assignment.roomId,
        videoId: assignment.videoId,
        sets: assignment.sets,
        reps: assignment.reps,
        restTime: assignment.restTime,
        position: assignment.position,
        isActive: assignment.isActive,
      };
      this.roomAssignments.set(assignmentData.id, assignmentData);
    });

    this.currentId = { 
      rooms: 11, 
      videos: sampleVideos.length + 1, 
      assignments: assignments.length + 1, 
      schedules: 1,
      customEntries: 1
    };
  }

  async getRooms(): Promise<Room[]> {
    return Array.from(this.rooms.values());
  }

  async getRoom(id: number): Promise<Room | undefined> {
    return this.rooms.get(id);
  }

  async createRoom(room: InsertRoom): Promise<Room> {
    const id = this.currentId.rooms++;
    const newRoom: Room = { 
      id, 
      number: room.number, 
      name: room.name, 
      isActive: room.isActive ?? false 
    };
    this.rooms.set(id, newRoom);
    return newRoom;
  }

  async updateRoom(id: number, room: Partial<Room>): Promise<Room | undefined> {
    const existing = this.rooms.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...room };
    this.rooms.set(id, updated);
    return updated;
  }

  async getVideos(): Promise<Video[]> {
    return Array.from(this.videos.values());
  }

  async getVideo(id: number): Promise<Video | undefined> {
    return this.videos.get(id);
  }

  async createVideo(video: InsertVideo): Promise<Video> {
    const id = this.currentId.videos++;
    const newVideo: Video = { 
      ...video, 
      id, 
      lastUsed: null,
      secondaryMuscle: video.secondaryMuscle || null,
      thumbnailUrl: video.thumbnailUrl || null
    };
    this.videos.set(id, newVideo);
    return newVideo;
  }

  async updateVideo(id: number, video: Partial<Video>): Promise<Video | undefined> {
    const existing = this.videos.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...video };
    this.videos.set(id, updated);
    return updated;
  }

  async updateVideoLastUsed(id: number): Promise<void> {
    const video = this.videos.get(id);
    if (video) {
      video.lastUsed = new Date();
      this.videos.set(id, video);
    }
  }

  async deleteVideo(id: number): Promise<boolean> {
    // First delete any schedules that reference this video
    const schedulesToDelete = Array.from(this.schedules.values()).filter(s => s.videoId === id);
    schedulesToDelete.forEach(schedule => this.schedules.delete(schedule.id));
    
    // Then delete the video
    return this.videos.delete(id);
  }

  async getRoomAssignments(): Promise<RoomAssignment[]> {
    return Array.from(this.roomAssignments.values());
  }

  async getRoomAssignmentsByRoom(roomId: number): Promise<RoomAssignment[]> {
    return Array.from(this.roomAssignments.values()).filter(a => a.roomId === roomId && a.isActive);
  }

  async createRoomAssignment(assignment: InsertRoomAssignment): Promise<RoomAssignment> {
    const id = this.currentId.assignments++;
    const newAssignment: RoomAssignment = { 
      id,
      roomId: assignment.roomId,
      videoId: assignment.videoId,
      sets: assignment.sets,
      reps: assignment.reps,
      restTime: assignment.restTime ?? 60,
      position: assignment.position,
      isActive: assignment.isActive ?? true
    };
    this.roomAssignments.set(id, newAssignment);
    return newAssignment;
  }

  async updateRoomAssignment(id: number, assignment: Partial<RoomAssignment>): Promise<RoomAssignment | undefined> {
    const existing = this.roomAssignments.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...assignment };
    this.roomAssignments.set(id, updated);
    return updated;
  }

  async deleteRoomAssignment(id: number): Promise<boolean> {
    return this.roomAssignments.delete(id);
  }

  async clearRoomAssignments(roomId: number): Promise<void> {
    const idsToDelete: number[] = [];
    this.roomAssignments.forEach((assignment, id) => {
      if (assignment.roomId === roomId) {
        idsToDelete.push(id);
      }
    });
    idsToDelete.forEach(id => this.roomAssignments.delete(id));
  }

  async getSchedules(): Promise<Schedule[]> {
    return Array.from(this.schedules.values());
  }

  async getSchedulesByDate(scheduleDate: string): Promise<Schedule[]> {
    return Array.from(this.schedules.values()).filter(s => s.scheduleDate === scheduleDate);
  }

  async getSchedulesByRoomAndDate(roomId: number, scheduleDate: string): Promise<Schedule[]> {
    return Array.from(this.schedules.values()).filter(s => s.roomId === roomId && s.scheduleDate === scheduleDate);
  }

  async getSchedulesByRoom(roomId: number): Promise<Schedule[]> {
    return Array.from(this.schedules.values()).filter(s => s.roomId === roomId);
  }

  async createSchedule(schedule: InsertSchedule): Promise<Schedule> {
    const id = this.currentId.schedules++;
    const newSchedule: Schedule = { 
      ...schedule, 
      id,
      restTime: schedule.restTime ?? 60,
      displayTitle: schedule.displayTitle || null,
      displayEquipment: schedule.displayEquipment || null,
      zoomLevel: schedule.zoomLevel || "1",
      verticalPosition: schedule.verticalPosition || "0"
    };
    this.schedules.set(id, newSchedule);
    return newSchedule;
  }

  async updateSchedule(id: number, schedule: Partial<Schedule>): Promise<Schedule | undefined> {
    const existing = this.schedules.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...schedule };
    this.schedules.set(id, updated);
    return updated;
  }

  async deleteSchedule(id: number): Promise<boolean> {
    return this.schedules.delete(id);
  }

  // Custom Entries
  async getCustomEntries(): Promise<CustomEntry[]> {
    return Array.from(this.customEntries.values());
  }

  async getCustomEntriesByCategory(category: string): Promise<CustomEntry[]> {
    return Array.from(this.customEntries.values()).filter(entry => entry.category === category);
  }

  async createCustomEntry(entry: InsertCustomEntry): Promise<CustomEntry> {
    // Check if entry already exists
    const existing = Array.from(this.customEntries.values()).find(
      e => e.category === entry.category && e.value === entry.value
    );
    
    if (existing) {
      return existing;
    }
    
    const id = this.currentId.customEntries++;
    const newEntry: CustomEntry = {
      ...entry,
      id,
      createdAt: new Date()
    };
    this.customEntries.set(id, newEntry);
    return newEntry;
  }

  async deleteCustomEntry(category: string, value: string): Promise<boolean> {
    const entry = Array.from(this.customEntries.values()).find(
      e => e.category === category && e.value === value
    );
    
    if (entry) {
      this.customEntries.delete(entry.id);
      return true;
    }
    
    return false;
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  async getRooms(): Promise<Room[]> {
    const { db } = await import("./db");
    const { rooms } = await import("@shared/schema");
    return await db.select().from(rooms);
  }

  async getRoom(id: number): Promise<Room | undefined> {
    const { db } = await import("./db");
    const { rooms } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    const [room] = await db.select().from(rooms).where(eq(rooms.id, id));
    return room || undefined;
  }

  async createRoom(room: InsertRoom): Promise<Room> {
    const { db } = await import("./db");
    const { rooms } = await import("@shared/schema");
    const [created] = await db.insert(rooms).values(room).returning();
    return created;
  }

  async updateRoom(id: number, room: Partial<Room>): Promise<Room | undefined> {
    const { db } = await import("./db");
    const { rooms } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    const [updated] = await db.update(rooms).set(room).where(eq(rooms.id, id)).returning();
    return updated || undefined;
  }

  async getVideos(): Promise<Video[]> {
    const { db } = await import("./db");
    const { videos } = await import("@shared/schema");
    return await db.select().from(videos);
  }

  async getVideo(id: number): Promise<Video | undefined> {
    const { db } = await import("./db");
    const { videos } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video || undefined;
  }

  async createVideo(video: InsertVideo): Promise<Video> {
    const { db } = await import("./db");
    const { videos } = await import("@shared/schema");
    const [created] = await db.insert(videos).values(video).returning();
    return created;
  }

  async updateVideo(id: number, video: Partial<Video>): Promise<Video | undefined> {
    const { db } = await import("./db");
    const { videos } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    const [updated] = await db.update(videos).set(video).where(eq(videos.id, id)).returning();
    return updated || undefined;
  }

  async updateVideoLastUsed(id: number): Promise<void> {
    const { db } = await import("./db");
    const { videos } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    await db.update(videos).set({ lastUsed: new Date() }).where(eq(videos.id, id));
  }

  async deleteVideo(id: number): Promise<boolean> {
    const { db } = await import("./db");
    const { videos } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    
    try {
      const result = await db.delete(videos).where(eq(videos.id, id));
      const deleted = (result.rowCount ?? 0) > 0;
      console.log(`Database delete result for video ${id}: ${deleted ? 'success' : 'not found'}, rowCount: ${result.rowCount}`);
      return deleted;
    } catch (error) {
      console.error(`Error deleting video ${id} from database:`, error);
      return false;
    }
  }

  async getRoomAssignments(): Promise<RoomAssignment[]> {
    const { db } = await import("./db");
    const { roomAssignments } = await import("@shared/schema");
    return await db.select().from(roomAssignments);
  }

  async getRoomAssignmentsByRoom(roomId: number): Promise<RoomAssignment[]> {
    const { db } = await import("./db");
    const { roomAssignments } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    return await db.select().from(roomAssignments).where(eq(roomAssignments.roomId, roomId));
  }

  async createRoomAssignment(assignment: InsertRoomAssignment): Promise<RoomAssignment> {
    const { db } = await import("./db");
    const { roomAssignments } = await import("@shared/schema");
    const [created] = await db.insert(roomAssignments).values(assignment).returning();
    return created;
  }

  async updateRoomAssignment(id: number, assignment: Partial<RoomAssignment>): Promise<RoomAssignment | undefined> {
    const { db } = await import("./db");
    const { roomAssignments } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    const [updated] = await db.update(roomAssignments).set(assignment).where(eq(roomAssignments.id, id)).returning();
    return updated || undefined;
  }

  async deleteRoomAssignment(id: number): Promise<boolean> {
    const { db } = await import("./db");
    const { roomAssignments } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    const result = await db.delete(roomAssignments).where(eq(roomAssignments.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async clearRoomAssignments(roomId: number): Promise<void> {
    const { db } = await import("./db");
    const { roomAssignments } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    await db.delete(roomAssignments).where(eq(roomAssignments.roomId, roomId));
  }

  async getSchedules(): Promise<Schedule[]> {
    const { db } = await import("./db");
    const { schedules } = await import("@shared/schema");
    const { asc } = await import("drizzle-orm");
    return await db.select().from(schedules).orderBy(asc(schedules.scheduleDate), asc(schedules.roomId), asc(schedules.position));
  }

  async getSchedulesByDate(scheduleDate: string): Promise<Schedule[]> {
    const { db } = await import("./db");
    const { schedules } = await import("@shared/schema");
    const { eq, asc } = await import("drizzle-orm");
    return await db.select().from(schedules).where(eq(schedules.scheduleDate, scheduleDate)).orderBy(asc(schedules.roomId), asc(schedules.position));
  }

  async getSchedulesByRoom(roomId: number): Promise<Schedule[]> {
    const { db } = await import("./db");
    const { schedules } = await import("@shared/schema");
    const { eq, asc } = await import("drizzle-orm");
    return await db.select().from(schedules).where(eq(schedules.roomId, roomId)).orderBy(asc(schedules.scheduleDate), asc(schedules.position));
  }

  async getSchedulesByRoomAndDate(roomId: number, scheduleDate: string): Promise<Schedule[]> {
    const { db } = await import("./db");
    const { schedules } = await import("@shared/schema");
    const { eq, and, asc } = await import("drizzle-orm");
    return await db.select().from(schedules).where(
      and(eq(schedules.roomId, roomId), eq(schedules.scheduleDate, scheduleDate))
    ).orderBy(asc(schedules.position));
  }

  async createSchedule(schedule: InsertSchedule): Promise<Schedule> {
    const { db } = await import("./db");
    const { schedules } = await import("@shared/schema");
    const [created] = await db.insert(schedules).values(schedule).returning();
    return created;
  }

  async updateSchedule(id: number, schedule: Partial<Schedule>): Promise<Schedule | undefined> {
    const { db } = await import("./db");
    const { schedules } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    const [updated] = await db.update(schedules).set(schedule).where(eq(schedules.id, id)).returning();
    return updated || undefined;
  }

  async deleteSchedule(id: number): Promise<boolean> {
    const { db } = await import("./db");
    const { schedules } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    const result = await db.delete(schedules).where(eq(schedules.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Custom Entries
  async getCustomEntries(): Promise<CustomEntry[]> {
    const { db } = await import("./db");
    const { customEntries } = await import("@shared/schema");
    return await db.select().from(customEntries);
  }

  async getCustomEntriesByCategory(category: string): Promise<CustomEntry[]> {
    const { db } = await import("./db");
    const { customEntries } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    return await db.select().from(customEntries).where(eq(customEntries.category, category));
  }

  async createCustomEntry(entry: InsertCustomEntry): Promise<CustomEntry> {
    const { db } = await import("./db");
    const { customEntries } = await import("@shared/schema");
    const { eq, and } = await import("drizzle-orm");
    
    // Check if entry already exists
    const [existing] = await db.select().from(customEntries).where(
      and(eq(customEntries.category, entry.category), eq(customEntries.value, entry.value))
    );
    
    if (existing) {
      return existing;
    }
    
    const [created] = await db.insert(customEntries).values(entry).returning();
    return created;
  }

  async deleteCustomEntry(category: string, value: string): Promise<boolean> {
    const { db } = await import("./db");
    const { customEntries } = await import("@shared/schema");
    const { eq, and } = await import("drizzle-orm");
    
    const result = await db.delete(customEntries).where(
      and(eq(customEntries.category, category), eq(customEntries.value, value))
    );
    
    return (result.rowCount ?? 0) > 0;
  }
}

export const storage = new DatabaseStorage();
