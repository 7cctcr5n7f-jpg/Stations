import fs from 'fs';
import path from 'path';
import { db } from './db.js';
import { videos, schedules } from '../shared/schema.js';
import { eq } from 'drizzle-orm';

export interface VideoValidationResult {
  id: number;
  title: string;
  url: string;
  status: 'valid' | 'missing_file' | 'invalid_path' | 'corrupt';
  fileSize?: number;
  error?: string;
}

export class VideoValidator {
  async validateAllVideos(): Promise<VideoValidationResult[]> {
    try {
      const allVideos = await db.select().from(videos);
      const results: VideoValidationResult[] = [];

      for (const video of allVideos) {
        const result = await this.validateSingleVideo(video);
        results.push(result);
      }

      return results;
    } catch (error) {
      throw new Error(`Video validation failed: ${error}`);
    }
  }

  private async validateSingleVideo(video: any): Promise<VideoValidationResult> {
    const result: VideoValidationResult = {
      id: video.id,
      title: video.title,
      url: video.url,
      status: 'valid'
    };

    try {
      // Check if URL path is valid
      if (!video.url || !video.url.startsWith('/uploads/')) {
        result.status = 'invalid_path';
        result.error = 'Invalid URL path';
        return result;
      }

      // Check if file exists
      const filePath = path.join(process.cwd(), video.url.substring(1));
      
      if (!fs.existsSync(filePath)) {
        result.status = 'missing_file';
        result.error = 'File not found on filesystem';
        return result;
      }

      // Check file size and basic integrity
      const stats = fs.statSync(filePath);
      result.fileSize = stats.size;

      if (stats.size === 0) {
        result.status = 'corrupt';
        result.error = 'File is empty';
        return result;
      }

      if (stats.size < 1000) { // Less than 1KB is likely corrupt
        result.status = 'corrupt';
        result.error = 'File too small, likely corrupt';
        return result;
      }

      // File exists and has reasonable size
      result.status = 'valid';
      
    } catch (error) {
      result.status = 'corrupt';
      result.error = `Validation error: ${error}`;
    }

    return result;
  }

  async cleanupInvalidVideos(): Promise<{ deleted: number; errors: string[] }> {
    const results = await this.validateAllVideos();
    const invalidVideos = results.filter(r => r.status !== 'valid');
    
    let deleted = 0;
    const errors: string[] = [];

    for (const invalid of invalidVideos) {
      try {
        // Delete from schedules first
        await db.delete(schedules).where(eq(schedules.videoId, invalid.id));
        
        // Delete video record
        await db.delete(videos).where(eq(videos.id, invalid.id));
        
        deleted++;
        console.log(`Cleaned up invalid video: ${invalid.title} (${invalid.error})`);
      } catch (error) {
        errors.push(`Failed to delete video ${invalid.id}: ${error}`);
      }
    }

    return { deleted, errors };
  }

  async getHealthSummary() {
    const results = await this.validateAllVideos();
    
    const summary = {
      total: results.length,
      valid: results.filter(r => r.status === 'valid').length,
      missing: results.filter(r => r.status === 'missing_file').length,
      corrupt: results.filter(r => r.status === 'corrupt').length,
      invalid: results.filter(r => r.status === 'invalid_path').length,
      totalFileSize: results
        .filter(r => r.fileSize)
        .reduce((sum, r) => sum + (r.fileSize || 0), 0),
      details: results.filter(r => r.status !== 'valid')
    };

    return summary;
  }
}

export const videoValidator = new VideoValidator();