import { Client } from '@replit/object-storage';
import { Response } from 'express';
import { randomUUID } from 'crypto';
import { Readable } from 'stream';

export class AppStorageService {
  private client: Client;

  constructor() {
    this.client = new Client();
  }

  // Upload a video file to App Storage
  async uploadVideo(videoBuffer: Buffer, originalFilename: string): Promise<string> {
    try {
      const fileId = randomUUID();
      const extension = originalFilename.split('.').pop() || 'mp4';
      const key = `videos/${fileId}.${extension}`;
      
      console.log(`📤 Uploading video to App Storage: ${key}`);
      
      const result = await this.client.uploadFromBytes(key, videoBuffer);
      
      if (!result.ok) {
        throw new Error(`Upload failed: ${result.error}`);
      }
      
      console.log(`✅ Video uploaded successfully: ${key}`);
      return key;
    } catch (error) {
      console.error('❌ App Storage video upload failed:', error);
      throw new Error(`Failed to upload video: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Upload a thumbnail to App Storage
  async uploadThumbnail(thumbnailBuffer: Buffer, videoId: number): Promise<string> {
    try {
      const key = `thumbnails/${videoId}.jpg`;
      
      console.log(`📤 Uploading thumbnail to App Storage: ${key}`);
      
      const result = await this.client.uploadFromBytes(key, thumbnailBuffer);
      
      if (!result.ok) {
        throw new Error(`Upload failed: ${result.error}`);
      }
      
      console.log(`✅ Thumbnail uploaded successfully: ${key}`);
      return key;
    } catch (error) {
      console.error('❌ App Storage thumbnail upload failed:', error);
      throw new Error(`Failed to upload thumbnail: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Download/stream a file from App Storage
  async downloadFile(key: string, res: Response): Promise<void> {
    try {
      console.log(`📥 Downloading from App Storage: ${key}`);
      
      const fileStream = this.client.downloadAsStream(key);
      
      // Set appropriate headers
      const contentType = key.includes('thumbnails/') ? 'image/jpeg' : 'video/mp4';
      res.set({
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=3600',
        'Cross-Origin-Resource-Policy': 'cross-origin'
      });

      // Handle stream errors
      fileStream.on('error', (error) => {
        console.error('❌ App Storage stream error:', error);
        if (!res.headersSent) {
          res.status(404).json({ error: 'File not found' });
        }
      });

      // Stream the file
      fileStream.pipe(res);
      
    } catch (error) {
      console.error('❌ App Storage download failed:', error);
      if (!res.headersSent) {
        res.status(404).json({ error: 'File not found' });
      }
    }
  }

  // Check if App Storage is available
  async isAvailable(): Promise<boolean> {
    try {
      // Try to list objects to check if App Storage is working
      const result = await this.client.list({ maxResults: 1 });
      return result.ok;
    } catch (error) {
      console.log('⚠️ App Storage not available, using local storage as fallback');
      return false;
    }
  }
}