import { exec } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import fs from 'fs/promises';
import { existsSync } from 'fs';

const execAsync = promisify(exec);

export interface ThumbnailGeneratorOptions {
  videoPath: string;
  outputPath: string;
  timeSeconds?: number;
  width?: number;
  height?: number;
}

export class ThumbnailGenerator {
  static async generateThumbnail(options: ThumbnailGeneratorOptions): Promise<string> {
    const {
      videoPath,
      outputPath,
      timeSeconds = 2,
      width = 320,
      height = 180
    } = options;

    try {
      // Ensure output directory exists
      const outputDir = path.dirname(outputPath);
      await fs.mkdir(outputDir, { recursive: true });

      // Get video duration first to handle short videos
      const probeCommand = `ffprobe -v quiet -show_entries format=duration -of csv=p=0 "${videoPath}"`;
      const { stdout: durationStr } = await execAsync(probeCommand);
      const duration = parseFloat(durationStr.trim());
      
      // Use a safe time position: minimum of requested time or 90% of video duration
      const safeTimeSeconds = Math.min(timeSeconds, Math.max(0.1, duration * 0.9));
      
      console.log(`Video duration: ${duration}s, using thumbnail time: ${safeTimeSeconds}s`);

      // Use ffmpeg to extract thumbnail at specified time
      const command = `ffmpeg -i "${videoPath}" -ss ${safeTimeSeconds} -vframes 1 -vf "scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:black" -y "${outputPath}"`;
      
      console.log(`Generating thumbnail: ${command}`);
      await execAsync(command);
      
      // Verify the thumbnail was created
      try {
        await fs.access(outputPath);
        console.log(`Thumbnail generated successfully: ${outputPath}`);
        return outputPath;
      } catch (error) {
        throw new Error(`Thumbnail file was not created: ${outputPath}`);
      }
    } catch (error) {
      console.error(`Failed to generate thumbnail for ${videoPath}:`, error);
      throw error;
    }
  }

  static async generateThumbnailFromVideo(videoId: number, videoPath: string): Promise<string> {
    const thumbnailFileName = `thumbnail_${videoId}.jpg`;
    const thumbnailPath = path.join('uploads', 'thumbnails', thumbnailFileName);
    
    // Verify input video file exists
    if (!existsSync(videoPath)) {
      throw new Error(`Source video file not found: ${videoPath}`);
    }

    console.log(`Generating thumbnail for video ${videoId}: ${videoPath} -> ${thumbnailPath}`);
    
    await this.generateThumbnail({
      videoPath,
      outputPath: thumbnailPath,
      timeSeconds: 2,
      width: 320,
      height: 180
    });

    // Double-check thumbnail was created
    if (!await this.thumbnailExists(videoId)) {
      throw new Error(`Thumbnail generation failed for video ${videoId}`);
    }

    console.log(`✅ Thumbnail generated successfully for video ${videoId}`);
    return `/uploads/thumbnails/${thumbnailFileName}`;
  }

  static getThumbnailPath(videoId: number): string {
    return `/uploads/thumbnails/thumbnail_${videoId}.jpg`;
  }

  static async thumbnailExists(videoId: number): Promise<boolean> {
    const thumbnailPath = path.join('uploads', 'thumbnails', `thumbnail_${videoId}.jpg`);
    try {
      await fs.access(thumbnailPath);
      return true;
    } catch {
      return false;
    }
  }
}