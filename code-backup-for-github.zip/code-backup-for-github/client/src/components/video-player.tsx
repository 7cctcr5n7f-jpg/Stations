import { useRef, useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ZoomIn, ZoomOut, Download, CheckCircle, Play } from "lucide-react";
import { videoCacheManager } from "@/lib/video-cache";
import logoPath from "@assets/10Rounds Logos_RGB-08_1750068981660.png";

interface VideoPlayerProps {
  assignment: {
    id: number;
    sets: number;
    reps: string | number; // Allow both string and number
    zoomLevel?: string;
    verticalPosition?: string;
    displayEquipment?: string;
    video: {
      id: number;
      title: string;
      url: string;
      duration: string;
      bodyPart: string;
      equipment: string;
    };
  };
  displayMode?: 'single' | 'split';
  videoCount?: number;
  isFullscreen?: boolean;
}

export default function VideoPlayer({ assignment, displayMode = 'single', videoCount = 1, isFullscreen = false }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const zoom = parseFloat(assignment.zoomLevel || "1");
  const verticalPos = parseFloat(assignment.verticalPosition || "0");
  const [videoSrc, setVideoSrc] = useState(assignment.video.url);
  const [isCached, setIsCached] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  // Initialize video with direct URL loading (no caching for stability)
  useEffect(() => {
    // Always use original URL for maximum stability
    setVideoSrc(assignment.video.url);
    setIsCached(false);
  }, [assignment.video.id, assignment.video.url]);

  useEffect(() => {
    if (videoRef.current) {
      const video = videoRef.current;
      
      const handleCanPlay = () => {
        setVideoLoaded(true);
        // Immediate play for cached videos, small delay for multi-video to prevent CPU spikes
        const playDelay = isCached ? 0 : (videoCount >= 3 ? Math.random() * 200 : 0);
        setTimeout(() => {
          video.play().catch(console.error);
        }, playDelay);
      };
      
      const handleLoadedData = () => {
        // Video is fully loaded and ready for smooth playback
        setVideoLoaded(true);
      };
      
      const handleError = (e: Event) => {
        console.error('Video failed to load:', videoSrc);
        setVideoError(true);
      };

      video.addEventListener('canplay', handleCanPlay);
      video.addEventListener('loadeddata', handleLoadedData);
      video.addEventListener('error', handleError);
      
      return () => {
        video.removeEventListener('canplay', handleCanPlay);
        video.removeEventListener('loadeddata', handleLoadedData);
        video.removeEventListener('error', handleError);
      };
    }
  }, [videoSrc, isCached, videoCount]);



  // Calculate height based on video count - only 3+ videos use half height, 1-2 videos use full height
  const containerHeight = videoCount >= 3 ? '50vh' : '100vh';
  const isCompactMode = videoCount >= 3;
  
  return (
    <div className="relative bg-white w-full h-full overflow-hidden" style={{ height: containerHeight }}>
      <video
        ref={videoRef}
        src={videoSrc}
        className={`${videoLoaded ? 'block' : 'hidden'} w-full`}
        style={{
          height: containerHeight,
          objectFit: 'contain',
          objectPosition: 'center',
          transform: `scale(${zoom}) translateY(${verticalPos}px)`,
          transformOrigin: 'center'
        }}
        loop
        muted
        playsInline
        autoPlay
        preload="auto"
        controls={false}
        disablePictureInPicture
      />
      
      {/* Standardized Reps Display - Top Right */}
      <div className={`absolute ${isCompactMode ? 'top-2 right-0' : 'top-6 right-0'} z-20`}>
        <div className={`bg-black/80 backdrop-blur-sm rounded-xl ${isCompactMode ? 'w-16 h-16 px-2 py-2' : 'w-24 h-24 px-4 py-4'} flex flex-col items-center justify-center text-center`}>
          {(() => {
            const repsStr = String(assignment.reps);
            const isOnlyNumber = /^\d+$/.test(repsStr);
            
            if (isOnlyNumber) {
              // Show number + "REPS" for pure numbers
              return (
                <>
                  <div className={`${isCompactMode ? 'text-lg' : 'text-3xl'} font-bold text-white mb-0.5`}>
                    {repsStr}
                  </div>
                  <div className={`${isCompactMode ? 'text-xs' : 'text-sm'} text-gray-300 uppercase tracking-wider leading-none`}>
                    REPS
                  </div>
                </>
              );
            } else {
              // Show custom text without "REPS" for text containing more than numbers
              // Split into number and text parts for different styling (supports decimal numbers)
              const match = repsStr.match(/^(\d+(?:\.\d+)?)\s*(.+)$/);
              if (match) {
                const [, number, text] = match;
                return (
                  <div className={`text-center leading-tight`}>
                    <div className={`${isCompactMode ? 'text-lg' : 'text-3xl'} font-bold text-white mb-0.5`}>
                      {number}
                    </div>
                    <div className={`${isCompactMode ? 'text-xs' : 'text-sm'} text-gray-300 uppercase tracking-wider leading-none`}>
                      {text}
                    </div>
                  </div>
                );
              } else {
                // Fallback for text without clear number/text separation
                return (
                  <div className={`${isCompactMode ? 'text-sm' : 'text-lg'} font-bold text-white text-center leading-tight`}>
                    {repsStr}
                  </div>
                );
              }
            }
          })()}
        </div>
        
        {/* Equipment Display - Below reps */}
        {(() => {
          // Get equipment from assignment or video
          const equipmentStr = assignment.displayEquipment || assignment.video.equipment;
          if (!equipmentStr) return null;
          
          // Take only the first equipment item for clean display
          const equipment = equipmentStr.split(',')[0].trim();
          if (!equipment) return null;
          
          return (
            <div className={`mt-1 bg-black/60 backdrop-blur-sm rounded-lg ${isCompactMode ? 'px-2 py-1' : 'px-3 py-1.5'} text-center`}>
              <div className={`${isCompactMode ? 'text-xs' : 'text-sm'} text-gray-200 uppercase tracking-wide font-medium`}>
                {equipment}
              </div>
            </div>
          );
        })()}
      </div>

      {/* Logo - Top Left */}
      <div className={`absolute ${isCompactMode ? 'top-2 left-0' : 'top-6 left-0'} z-20`}>
        <img 
          src={logoPath} 
          alt="10Rounds Logo"
          className={`${isCompactMode ? 'w-16 h-16' : 'w-24 h-24'} object-contain`}
        />
      </div>
      
      {/* Video Title Overlay - Top Center */}
      <div className={`absolute ${isCompactMode ? 'top-2' : 'top-6'} left-1/2 transform -translate-x-1/2 z-10`}>
        <div className={`bg-white/90 backdrop-blur-sm rounded-lg ${isCompactMode ? 'px-3 py-1.5' : 'px-6 py-3'} text-center`}>
          <h3 className={`${isCompactMode ? 'text-lg' : 'text-2xl'} font-bold text-black`}>{assignment.video.title}</h3>
        </div>
      </div>
      
      {/* Loading/Error placeholder */}
      {(!videoLoaded && !videoError) && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-900 text-white">
          <div className="text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-white mx-auto mb-4"></div>
            <h3 className="text-2xl font-bold mb-4">{assignment.video.title}</h3>
            <p className="text-gray-400 text-lg">Loading video...</p>
          </div>
        </div>
      )}
      
      {videoError && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-900 text-white">
          <div className="text-center">
            <Play className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-2xl font-bold mb-4">{assignment.video.title}</h3>
            <p className="text-red-400 text-lg">Video failed to load</p>
          </div>
        </div>
      )}
    </div>
  );
}
