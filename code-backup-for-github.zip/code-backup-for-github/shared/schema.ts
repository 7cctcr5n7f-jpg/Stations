import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  number: integer("number").notNull().unique(),
  name: text("name").notNull(),
  isActive: boolean("is_active").default(false),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  duration: text("duration").notNull(),
  bodyPart: text("body_part").notNull(), // Primary muscle
  secondaryMuscle: text("secondary_muscle").default(""), // Secondary muscle
  equipment: text("equipment").notNull(),
  lastUsed: timestamp("last_used"),
  thumbnailUrl: text("thumbnail_url"),
});

export const roomAssignments = pgTable("room_assignments", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").notNull(),
  videoId: integer("video_id").notNull(),
  sets: integer("sets").notNull(),
  reps: integer("reps").notNull(),
  restTime: integer("rest_time").default(60),
  position: integer("position").notNull(), // 1 or 2 for split screen
  isActive: boolean("is_active").default(true),
});

export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").notNull(),
  videoId: integer("video_id").notNull(),
  scheduleDate: text("schedule_date").notNull(), // YYYY-MM-DD format
  sets: integer("sets").notNull(),
  reps: text("reps").notNull(), // Changed from integer to text to support "5 each side"
  restTime: integer("rest_time").default(60),
  position: integer("position").notNull(),
  // Temporary display overrides - only for this schedule entry
  displayTitle: text("display_title"), // Override video title for this schedule
  displayEquipment: text("display_equipment"), // Override equipment for this schedule
  zoomLevel: text("zoom_level").default("1"), // Video zoom level
  verticalPosition: text("vertical_position").default("0"), // Vertical position offset
});

export const customEntries = pgTable("custom_entries", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(), // 'bodyPart', 'secondaryMuscle', 'equipment'
  value: text("value").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRoomSchema = createInsertSchema(rooms).omit({
  id: true,
});

export const insertVideoSchema = createInsertSchema(videos).omit({
  id: true,
  lastUsed: true,
});

export const insertRoomAssignmentSchema = createInsertSchema(roomAssignments).omit({
  id: true,
});

export const insertScheduleSchema = createInsertSchema(schedules).omit({
  id: true,
});

export const insertCustomEntrySchema = createInsertSchema(customEntries).omit({
  id: true,
  createdAt: true,
});

export type Room = typeof rooms.$inferSelect;
export type Video = typeof videos.$inferSelect;
export type RoomAssignment = typeof roomAssignments.$inferSelect;
export type Schedule = typeof schedules.$inferSelect;
export type CustomEntry = typeof customEntries.$inferSelect;

export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type InsertRoomAssignment = z.infer<typeof insertRoomAssignmentSchema>;
export type InsertCustomEntry = z.infer<typeof insertCustomEntrySchema>;
export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
