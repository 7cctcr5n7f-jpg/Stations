# GymFlow - Fitness Video Management System

## Overview
GymFlow, rebranded as TENROUNDS, is a full-stack web application for managing and displaying fitness videos across multiple workout rooms in a gym setting. It provides distinct interfaces for administrators (trainers) to manage content and schedules, and for members (users) to view workout content. The system aims to streamline gym operations, enhance the member workout experience, and provide flexible content management. Its core capabilities include dynamic video scheduling, multi-video room displays, and robust content organization, all designed to support a boxing-themed workout environment with distinct "rounds."

## User Preferences
Preferred communication style: Simple, everyday language.

## Recent Changes
- **August 22, 2025**: Fixed video disappearing issue by disabling aggressive file integrity auto-deletion. Videos now stay permanently in the library.
- **August 25, 2025**: Successfully restored 95 broken video links by merging duplicate records and preserving all valuable metadata (equipment, muscle groups). File integrity system confirmed in safe mode - videos are fully protected against future deletion.
- **August 31, 2025**: Implemented comprehensive backup system with database export script, Object Storage protection, and automatic checkpoints. All 2500+ videos now permanently stored in Object Storage with full duplicate prevention system.

## System Architecture

### Frontend
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui
- **Routing**: Wouter
- **State Management**: TanStack React Query
- **Build Tool**: Vite
- **UI/UX**: Boxing-themed design with circular room selectors, gradient backgrounds, blue accents, and glow effects. Automatic full-screen mode on round entry. Video display automatically positions based on count (centered for 1, split for 2, 2x2 grid for 3-4 videos). White backgrounds for video displays, with flexible video positioning controls (zoom, vertical alignment). Compact multi-select displays with small badges showing all selected items. Room names use proper boxing gym terminology (Round 1: Warm Up, Round 2: Weights Section, etc.).

### Backend
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript (ESM)
- **API Pattern**: RESTful API
- **Development**: Hot reload with `tsx`

### Database
- **ORM**: Drizzle ORM
- **Database**: PostgreSQL (configured for Neon serverless)
- **Schema**: Type-safe with Zod validation
- **Entities**: Rooms, Videos, Room Assignments, Schedules.
- **Persistence**: All video and schedule data is persistently stored in PostgreSQL.

### Core Features & Design Decisions
- **Video Management**: Comprehensive video upload (single/batch, drag-and-drop), editing (name, body part, equipment), and deletion. Automatic thumbnail generation. Dynamic options for body parts and equipment, with auto-capitalization and categorization.
- **Scheduling System**: Date-based scheduling, allowing independent video schedules per day. Supports up to 4 videos per room/round. Drag-and-drop exercise reorganization in schedule table. Automatic daily schedule switching for room displays.
- **Room Display**: Real-time display of assigned videos with workout parameters (reps, body part, equipment). Continuous video looping. Supports automatic full-screen mode. Displays next day's equipment preview.
- **Admin Dashboard**: Centralized management for videos, schedules, and live room monitoring. Provides a real-time round status grid and editable round headings/reps with live synchronization. Visual status indicators: green for completed rooms/days, red for incomplete.
- **Equipment Planning**: Color-coded equipment view across weekly schedules for trainers to plan equipment setup. Consistent color assignment per equipment type throughout the week. Exit functionality to return to main dashboard. Equipment-specific scheduling allows trainers to select specific equipment from each video's options, with visual indicators (red background/pulsing dot) for videos requiring equipment selection when multiple options are available.
- **Enhanced Video Caching**: Advanced multi-layer caching system with memory cache, priority-based preloading, and smart fallback strategies. Features automatic cache cleanup, proactive video downloading, and seamless offline playbook capability.
- **Data Integrity**: Schedule changes only modify temporary display overrides for specific dates, protecting original video metadata.
- **Validation**: Automated video file integrity checking and health dashboard.
- **Security**: Password protection for admin access.

## Backup & Recovery System

### Automatic Protection
- **Object Storage**: All videos stored permanently in Replit Object Storage, protected from workspace resets
- **Agent Checkpoints**: Replit automatically creates checkpoints at key development milestones
- **Database Persistence**: PostgreSQL database survives workspace resets with automatic persistence

### Manual Backup Options
1. **Database Export Script**: Run `node backup-database.mjs` to create complete SQL backup file
2. **Database Point-in-Time Recovery**: Enable "History Retention" in Database Settings for automatic point-in-time restore
3. **Code Backup**: Use Git pane to commit code changes to version control

### Recovery Procedures
- **Video Recovery**: Videos in Object Storage are permanent and automatically available after workspace resets
- **Database Recovery**: Import SQL backup file or use point-in-time restore feature in Database Settings
- **Code Recovery**: Use Agent Checkpoints rollback or Git history to restore previous code versions

### Backup Schedule Recommendations
- **Immediate**: After major uploads or system changes (use database export script)
- **Daily**: Enable database history retention for automatic point-in-time recovery
- **Weekly**: Commit code changes to Git for version control backup

## External Dependencies

### Core
- `@neondatabase/serverless`: PostgreSQL connection
- `drizzle-orm`: ORM for database operations
- `@tanstack/react-query`: Server state management
- `@radix-ui/*`: Headless UI components
- `ffmpeg`: Used for video thumbnail generation during upload.

### UI/Styling
- `shadcn/ui`: Accessible UI component library
- `Tailwind CSS`: Utility-first CSS framework
- `Lucide React`: Icon library

### Development (Replit-specific)
- `@replit/vite-plugin-runtime-error-modal`
- `@replit/vite-plugin-cartographer`